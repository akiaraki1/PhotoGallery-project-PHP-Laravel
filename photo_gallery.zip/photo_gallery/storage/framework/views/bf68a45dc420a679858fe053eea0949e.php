<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name', 'Фотогалерея')); ?> — <?php echo e(__('categories.' . $category)); ?></title>

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/basic.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/header.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/mainCategory.css']); ?>
    </head>
    <body>
        <header>

            <h1>Фотографии в категории «<?php echo e(__('categories.' . $category)); ?>».</h1>

            <nav>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('gallery.category_form', $category)); ?>">Добавить новый пост в категорию</a>
                
                    <div class="user-avatar-block">
                        <?php if(Auth::user()->avatar_image): ?>
                            <img src="<?php echo e(asset('storage/' . Auth::user()->avatar_image)); ?>" alt="Аватар">
                        <?php else: ?>
                            <div class="avatar-placeholder"></div>
                        <?php endif; ?>
                        <span><?php echo e(Auth::user()->name); ?></span>
                    </div>

                    <?php if(Route::has('profile.edit')): ?>
                        <a
                            href="<?php echo e(route('profile.edit')); ?>"
                        >
                                    <?php echo e(__('Profile')); ?>

                        </a>
                    <?php endif; ?>
            
                    <?php if(Route::has('logout')): ?>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit"><?php echo e(__('Log Out')); ?> </button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </nav>
        </header>

        <main>

            <?php if(session('status')): ?>
                <script>
                    confirm(<?php echo json_encode(session('status'), 15, 512) ?>);
                </script>
            <?php endif; ?>
            
            <?php $__empty_1 = true; $__currentLoopData = $photoGalleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photoGallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <div class="card">
                    <img class="category" src="<?php echo e(asset('storage/' . $photoGallery->image)); ?>" alt="<?php echo e($photoGallery->title); ?>">

                    <div>
                        <h3><?php echo e($photoGallery->title); ?></h3>
                        <p><?php echo e($photoGallery->description); ?></p>
                    </div>

                    <?php if(auth()->guard()->check()): ?>
                        <div class="card-actions">

                            <a href="<?php echo e(route('gallery.show', ['category' => $category, 'photoGallery' => $photoGallery])); ?>">Посмотреть</a>

                            <?php if(auth()->id() === $photoGallery->user_id): ?>
                                <a href="<?php echo e(route('gallery.edit', ['category' => $category, 'photoGallery' => $photoGallery])); ?>">Редактировать</a>

                                <form method="POST" action="<?php echo e(route('gallery.destroy', ['category' => $category, 'photoGallery' => $photoGallery])); ?>"
                                      onsubmit="return confirm('Удалить это изображение?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit">Удалить</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>В этой категории пока нет фотографий.</p>
            <?php endif; ?>

            <div class="pagination">
                <?php echo e($photoGalleries->appends(request()->query())->links('pagination::bootstrap-5')); ?>

            </div>
        </main>

    </body>
</html><?php /**PATH C:\OSPanel\home\photo_gallery.local\photo_gallery\resources\views/gallery_category/category.blade.php ENDPATH**/ ?>
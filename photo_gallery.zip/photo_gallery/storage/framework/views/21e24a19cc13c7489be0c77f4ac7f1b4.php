<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name', 'Фотогалерея')); ?> — Сброс пароля</title>

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/basic.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/header.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/mainLoginRegisterForgotPasswordCategoryForm.css']); ?>
    </head>
    <body>
        <header>
            <h1>Фотогалерея</h1>
            <nav>
                <?php if(Route::has('index')): ?>
                    <a 
                        href="<?php echo e(route('index')); ?>"
                    >
                        <?php echo e(__('Back to home page')); ?>

                    </a>
                <?php endif; ?>
                <?php if(Route::has('login')): ?>
                    <a
                        href="<?php echo e(route('login')); ?>"
                    >
                        <?php echo e(__('Log in')); ?>

                    </a>
                <?php endif; ?>
            </nav>
        </header>

        <main>
            <div class="form-card">
                <form method="POST" action="<?php echo e(route('password.email')); ?>">
                    <?php echo csrf_field(); ?>

                    <h2>Забыли пароль?</h2>

                    <?php if(session('status')): ?>
                        <div class="status-message">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <p>
                        Нет проблем. Укажите свой email — мы отправим ссылку для сброса пароля, по которой вы сможете выбрать новый.
                    </p>

                    

                    <div>
                        <label for="email">Email</label>
                        <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="last">
                        <button type="submit">Отправить ссылку</button>
                    </div>
                </form>
            </div>
        </main>
    </body>
</html>
<?php /**PATH C:\OSPanel\home\photo_gallery.local\photo_gallery\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>
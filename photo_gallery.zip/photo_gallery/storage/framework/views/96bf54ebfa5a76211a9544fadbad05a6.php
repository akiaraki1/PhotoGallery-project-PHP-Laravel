<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name', 'Фотогалерея')); ?> — Профиль</title>

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/basic.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/header.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/mainProfile.css']); ?>
    </head>
    <body>
        <header>

            <h1>Фотогалерея</h1>

            <nav>
                <?php if(auth()->guard()->check()): ?>
                    <div class="user-avatar-block">
                        <?php if(Auth::user()->avatar_image): ?>
                            <img src="<?php echo e(asset('storage/' . Auth::user()->avatar_image)); ?>" alt="Аватар">
                        <?php else: ?>
                            <div class="avatar-placeholder"></div>
                        <?php endif; ?>
                        <span><?php echo e(Auth::user()->name); ?></span>
                    </div>

                    <a href="<?php echo e(route('photo_gallery')); ?>"><?php echo e(__('Gallery')); ?></a>

                    <?php if(Route::has('logout')): ?>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit"><?php echo e(__('Log Out')); ?> </button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </nav>
        </header>

        <main>
            <h2>Профиль</h2>

            <?php if(session('status')): ?>
                <script>
                    confirm(<?php echo json_encode(session('status'), 15, 512) ?>);
                </script>
            <?php endif; ?>

            <!-- Информация профиля -->
            <section>
                <h3>Информация профиля</h3>
                <p>Обновите фотографию, имя и email вашего аккаунта.</p>
                <form method="POST" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <section>
                        <h3>Аватар</h3>

                        <?php if(Auth::user()->avatar_image): ?>
                            <img src="<?php echo e(asset('storage/' . Auth::user()->avatar_image)); ?>" alt="Аватар" class="avatar-preview">
                        <?php else: ?>
                            <div class="avatar-preview avatar-preview--empty"></div>
                        <?php endif; ?>

                        <input type="file" name="avatar_image" accept="image/jpeg,image/png,image/webp">

                        <p>Загрузите изображение или гифку. Максимальный размер изображения: 500×500 px. Максимальный размер файла изображения 5 МБ. Форматы изображений: jpeg,jpg,png,webp,gif.</p>
                    </section>
                    <p>
                        <label for="name">Имя</label>
                        <input type="text" id="name" name="name" value="<?php echo e(old('name', Auth::user()->name)); ?>" required autofocus autocomplete="name">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                    <p>
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo e(old('email', Auth::user()->email)); ?>" required autocomplete="username">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                    <p>
                        <button type="submit">Сохранить</button>
                    </p>
                </form>
            </section>

            <!-- Смена пароля -->
            <section>
                <h3>Смена пароля</h3>
                <p>Используйте длинный случайный пароль для безопасности.</p>
                <form method="POST" action="<?php echo e(route('password.update')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <p>
                        <label for="current_password">Текущий пароль</label>
                        <input type="password" id="current_password" name="current_password" required autocomplete="current-password">
                        <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                    <p>
                        <label for="password">Новый пароль</label>
                        <input type="password" id="password" name="password" required autocomplete="new-password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                    <p>
                        <label for="password_confirmation">Повторите пароль</label>
                        <input type="password" id="password_confirmation" name="password_confirmation" required autocomplete="new-password">
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                    <p>
                        <button type="submit">Сохранить</button>
                    </p>
                </form>
            </section>

            <!-- Удаление аккаунта -->
            <section>
                <h3>Удаление аккаунта</h3>
                <p>После удаления все данные будут безвозвратно потеряны. Перед удалением сохраните нужные данные.</p>
                <form method="POST" action="<?php echo e(route('profile.destroy')); ?>" onsubmit="return confirm('Вы уверены? Аккаунт будет удалён безвозвратно.')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <p>
                        <label for="delete_password">Пароль</label>
                        <input type="password" id="delete_password" name="password" required placeholder="Введите пароль для подтверждения">
                        <?php $__errorArgs = ['password', 'userDeletion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                    <p>
                        <button type="submit">Удалить аккаунт</button>
                    </p>
                </form>
            </section>
        </main>
    </body>
</html>
<?php /**PATH C:\OSPanel\home\photo_gallery.local\photo_gallery\resources\views/profile/edit.blade.php ENDPATH**/ ?>
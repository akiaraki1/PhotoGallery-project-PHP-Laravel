<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name', 'Фотогалерея')); ?> — Редактирование поста</title>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/basic.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/header.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/mainLoginRegisterForgotPasswordCategoryForm.css']); ?>
     
    </head>
    <body>
        <header>
                <h1>Редактирование поста</h1>

                <nav>
                <?php if(auth()->guard()->check()): ?>
                    <div class="user-avatar-block">
                        <?php if(Auth::user()->avatar_image): ?>
                            <img src="<?php echo e(asset('storage/' . Auth::user()->avatar_image)); ?>" alt="Аватар">
                        <?php else: ?>
                            <div class="avatar-placeholder"></div>
                        <?php endif; ?>
                        <span><?php echo e(Auth::user()->name); ?></span>
                    </div>

                    <?php if(Route::has('profile.edit')): ?>
                        <a
                            href="<?php echo e(route('profile.edit')); ?>"
                        >
                                    <?php echo e(__('Profile')); ?>

                        </a>
                    <?php endif; ?>
            
                    <?php if(Route::has('logout')): ?>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit"><?php echo e(__('Log Out')); ?> </button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </nav>
        </header>

        <main>
            <div class="form-card">
                <form action="<?php echo e(route('gallery.update', ['category' => $category, 'photoGallery' => $photoGallery])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <h1>Редактировать запись</h1>

                    <?php if(session('status')): ?>
                        <div class="status-message">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                
                    <div>
                        <label for="image">Изображение</label>
                        <img src="<?php echo e(asset('storage/' . $photoGallery->image)); ?>" alt="<?php echo e($photoGallery->title); ?>">
                        <input type="file" name="image" id="image">
                        <p>Размер файла — до 5 МБ. Габариты изображения — от 300×300 до 500×500 px. Рекомендуемый размер изображения 400x400 px. Форматы: jpeg, jpg, png, webp. </p>
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="error"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="title">Заголовок</label>
                        <input type="text" name="title" placeholder="Не более 50 символов."value="<?php echo e(old('title', $photoGallery->title)); ?>">
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="error"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="description">Описание</label>
                        <textarea name="description" placeholder="Не более 150 символов."><?php echo e(old('description', $photoGallery->description)); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="error"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="last">
                    <button type="submit" >Сохранить изменения</button>
                    </div>
                </form>
            </div>
        </main>
    </body>
</html><?php /**PATH C:\OSPanel\home\photo_gallery.local\photo_gallery\resources\views/gallery_category/edit.blade.php ENDPATH**/ ?>
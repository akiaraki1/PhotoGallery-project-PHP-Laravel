<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name', 'Фотогалерея')); ?></title>

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/basic.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/header.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/mainIndexPhotoGallery.css']); ?>
    </head>
    <body>
        <header>
            <h1>Фотогалерея</h1>

            <nav>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Route::has('photo_gallery')): ?>
                        <a
                            href="<?php echo e(route('photo_gallery')); ?>"
                        >
                            <?php echo e(__('Log in')); ?>

                        </a>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                        <a
                            href="<?php echo e(route('login')); ?>"
                        >
                            <?php echo e(__('Log in')); ?>

                        </a>
                    <?php endif; ?>

                    <?php if(Route::has('register')): ?>
                        <a
                            href="<?php echo e(route('register')); ?>"
                        >
                                <?php echo e(__('Register')); ?>

                        </a>
                    <?php endif; ?>
                <?php endif; ?>
            </nav>
        </header>
        <main>
            <div class="card">
                <img src="<?php echo e(asset('images/categories/nature.jpg')); ?>" alt="Природа">
                <div class="card-body">
                    <h3>Природа</h3>
                    <p>Горы, леса, реки и нетронутые уголки дикой природы.</p>
                </div>
            </div>

            <div class="card">
                <img src="<?php echo e(asset('images/categories/city.jpg')); ?>" alt="Города">
                <div class="card-body">
                    <h3>Города</h3>
                    <p>Уличная жизнь, небоскрёбы и огни мегаполисов ночью и днём.</p>
                </div>
            </div>

            <div class="card">
                 <img src="<?php echo e(asset('images/categories/architecture.jpg')); ?>" alt="Архитектура">
                <div class="card-body">
                    <h3>Архитектура</h3>
                    <p>Фасады, мосты и инженерные сооружения разных эпох и стилей.</p>
                </div>
            </div>

            <div class="card">
                <img src="<?php echo e(asset('images/categories/portrait.jpg')); ?>" alt="Портреты">
                <div class="card-body">
                    <h3>Портреты</h3>
                    <p>Эмоции, характеры и истории людей в кадре.</p>
                </div>
            </div>

            <div class="card">
                <img src="<?php echo e(asset('images/categories/travel.jpg')); ?>" alt="Путешествия">
                <div class="card-body">
                    <h3>Путешествия</h3>
                    <p>Достопримечательности, культуры и виды со всего мира.</p>
                </div>
            </div>

            <div class="card">
                <img src="<?php echo e(asset('images/categories/animal.jpg')); ?>" alt="Животные">
                <div class="card-body">
                    <h3>Животные</h3>
                    <p>Дикие и домашние животные в их естественной среде.</p>
                </div>
            </div>
        </main>
    </body>
</html>
<?php /**PATH C:\OSPanel\home\photo_gallery.local\photo_gallery\resources\views/index.blade.php ENDPATH**/ ?>
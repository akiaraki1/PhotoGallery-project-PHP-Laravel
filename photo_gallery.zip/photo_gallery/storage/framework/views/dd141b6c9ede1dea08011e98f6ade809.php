<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name', 'Фотогалерея')); ?> — Вход</title>
        
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/basic.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/header.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/mainLoginRegisterForgotPasswordCategoryForm.css']); ?>
        
    </head>
    <body>
        <header>
            
            <h1>Фотогалерея</h1>

            <nav>
                <?php if(Route::has('index')): ?>
                    <a 
                        href="<?php echo e(route('index')); ?>"
                    >
                        <?php echo e(__('Back to home page')); ?>

                    </a>
                <?php endif; ?>
                
                <?php if(Route::has('register')): ?>
                    <a
                        href="<?php echo e(route('register')); ?>"
                    >
                                <?php echo e(__('Register')); ?>

                    </a>
                <?php endif; ?>
            </nav>
        </header>

        <main>
            <div class="form-card">
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>

                    <h2>Вход</h2>

                    <?php if(session('status')): ?>
                        <div class="status-message">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div>
                        <label for="email">Email</label>
                        <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus autocomplete="username">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="password">Пароль</label>
                        <input type="password" name="password" required autocomplete="current-password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="checkbox-row">
                            <input type="checkbox" name="remember">
                            <span>Запомнить меня</span>
                    </div>

                    <div class="last">
                        <?php if(Route::has('password.request')): ?>
                            <a href="<?php echo e(route('password.request')); ?>">Забыли пароль?</a>
                        <?php endif; ?>
                        <button type="submit">Войти</button>
                    </div>
                </form>
            </div>
        </main>
    </body>
</html><?php /**PATH C:\OSPanel\home\photo_gallery.local\photo_gallery\resources\views/auth/login.blade.php ENDPATH**/ ?>
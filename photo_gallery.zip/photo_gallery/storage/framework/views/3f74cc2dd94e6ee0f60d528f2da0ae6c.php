<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name', 'Фотогалерея')); ?> — Просмотр поста</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/basic.css']); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/header.css']); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/mainShow.css']); ?>
</head>
    <body>
        <header>
                <h1>Просмотр фото</h1>

                <nav>
                <?php if(auth()->guard()->check()): ?>
                    <div class="user-avatar-block">
                        <?php if(Auth::user()->avatar_image): ?>
                            <img src="<?php echo e(asset('storage/' . Auth::user()->avatar_image)); ?>" alt="Аватар">
                        <?php else: ?>
                            <div class="avatar-placeholder"></div>
                        <?php endif; ?>
                        <span><?php echo e(Auth::user()->name); ?></span>
                    </div>

                    <?php if(Route::has('profile.edit')): ?>
                        <a
                            href="<?php echo e(route('profile.edit')); ?>"
                        >
                                    <?php echo e(__('Profile')); ?>

                        </a>
                    <?php endif; ?>
            
                    <?php if(Route::has('logout')): ?>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit"><?php echo e(__('Log Out')); ?> </button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </nav>
        </header>

        <main>
            <section>
                <img class="show" src="<?php echo e(asset('storage/' . $photoGallery->image)); ?>" alt="<?php echo e($photoGallery->title); ?>">

                <h1 class="show"><?php echo e($photoGallery->title); ?></h1>

                <p class="show"><?php echo e($photoGallery->description); ?></p>

                <div class="show">
                    <?php if(auth()->guard()->check()): ?>

                        <a class="show" href="<?php echo e(route('gallery.category', ['category' => $category])); ?>">← Назад в категорию</a>
                    
                        <?php if(auth()->id() === $photoGallery->user_id): ?>
                            <a class="show" href="<?php echo e(route('gallery.edit', ['category' => $category, 'photoGallery' => $photoGallery])); ?>">Редактировать</a>

                            <form class="show" action="<?php echo e(route('gallery.destroy', ['category' => $category, 'photoGallery' => $photoGallery])); ?>" method="POST"
                                onsubmit="return confirm('Удалить это изображение?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="show" type="submit">Удалить</button>
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </section>
        </main>
    </body>
</html><?php /**PATH C:\OSPanel\home\photo_gallery.local\photo_gallery\resources\views/gallery_category/show.blade.php ENDPATH**/ ?>
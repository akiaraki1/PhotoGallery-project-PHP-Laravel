<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name', 'Фотогалерея')); ?> — гелереи</title>

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/basic.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/header.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/mainIndexPhotoGallery.css']); ?>
    </head>
    <body>
        <header>
            <h1>Фотогалерея</h1>

            <p>Добавляйте свои фотографии в указанные ниже категории галерей.</p>

            <nav>
                <?php if(auth()->guard()->check()): ?>
                    <div class="user-avatar-block">
                        <?php if(Auth::user()->avatar_image): ?>
                            <img src="<?php echo e(asset('storage/' . Auth::user()->avatar_image)); ?>" alt="Аватар">
                        <?php else: ?>
                            <div class="avatar-placeholder"></div>
                        <?php endif; ?>
                        <span><?php echo e(Auth::user()->name); ?></span>
                    </div>

                    <?php if(Route::has('profile.edit')): ?>
                        <a
                            href="<?php echo e(route('profile.edit')); ?>"
                        >
                                    <?php echo e(__('Profile')); ?>

                        </a>
                    <?php endif; ?>
            
                    <?php if(Route::has('logout')): ?>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit"><?php echo e(__('Log Out')); ?> </button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </nav>
        </header>

        <main>

            <?php if(session('status')): ?>
                <script>
                    confirm(<?php echo json_encode(session('status'), 15, 512) ?>);
                </script>
            <?php endif; ?>

            <div class="card">
                <a href="<?php echo e(route('gallery.category', ['category' => 'nature'])); ?>">
                    <img src="<?php echo e(asset('images/categories/nature.jpg')); ?>" alt="Природа">
                    <div class="card-body">
                        <h3>Природа</h3>
                        <p>Горы, леса, реки и нетронутые уголки дикой природы.</p>
                    </div>
                </a>
            </div>

            <div class="card">
                <a href="<?php echo e(route('gallery.category', ['category' => 'cities'])); ?>">
                    <img src="<?php echo e(asset('images/categories/city.jpg')); ?>" alt="Города">
                    <div class="card-body">
                        <h3>Города</h3>
                        <p>Уличная жизнь, небоскрёбы и огни мегаполисов ночью и днём.</p>
                    </div>
                </a>
            </div>

            <div class="card">
                <a href="<?php echo e(route('gallery.category', ['category' => 'architecture'])); ?>">
                    <img src="<?php echo e(asset('images/categories/architecture.jpg')); ?>" alt="Архитектура">
                    <div class="card-body">
                        <h3>Архитектура</h3>
                        <p>Фасады, мосты и инженерные сооружения разных эпох и стилей.</p>
                    </div>
                </a>
            </div>

            <div class="card">
                <a href="<?php echo e(route('gallery.category', ['category' => 'portraits'])); ?>">
                    <img src="<?php echo e(asset('images/categories/portrait.jpg')); ?>" alt="Портреты">
                    <div class="card-body">
                        <h3>Портреты</h3>
                        <p>Эмоции, характеры и истории людей в кадре.</p>
                    </div>
                </a>
            </div>

            <div class="card">
                <a href="<?php echo e(route('gallery.category', ['category' => 'travel'])); ?>">
                    <img src="<?php echo e(asset('images/categories/travel.jpg')); ?>" alt="Путешествия">
                    <div class="card-body">
                        <h3>Путешествия</h3>
                        <p>Достопримечательности, культуры и виды со всего мира.</p>
                    </div>
                </a>
            </div>

            <div class="card">
                <a href="<?php echo e(route('gallery.category', ['category' => 'animals'])); ?>">
                    <img src="<?php echo e(asset('images/categories/animal.jpg')); ?>" alt="Животные">
                    <div class="card-body">
                        <h3>Животные</h3>
                        <p>Дикие и домашние животные в их естественной среде.</p>
                    </div>
                </a>
            </div>
        </main>
    </body>
</html>
<?php /**PATH C:\OSPanel\home\photo_gallery.local\photo_gallery\resources\views/photo_gallery.blade.php ENDPATH**/ ?>